#Apagar a memoria do r
remove(list=ls())
#instalar o pacote (retire o "#" antes de executar)
#install.packages("av")

#Ativar o pacote
library(av)

#Abrir o manual
?av

#Indicar a masta de trabalho
setwd("D:/Videos/_Dicas/Video stop motion")

#Criar nome das figuras
NOmes=paste("_im (",1:306,").jpg",sep="")

#Juntar imagens em um vídeo
av_encode_video(  NOmes,output = "Video1.mp4",  framerate = 30)
